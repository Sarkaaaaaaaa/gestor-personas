const validateUser = sessionStorage.getItem("Usuario logeado"); // Intenta obtener el valor de la clave "Usuario logeado" del sessionStorage

if(validateUser == null){ // Comprueba si no hay un usuario logueado (si el valor es null)
    window.location.href = 'Inicio_sesion.html'; // Si no hay usuario logueado, redirige al usuario a la página de inicio de sesión
}
