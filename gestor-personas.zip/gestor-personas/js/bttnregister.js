const login = document.getElementById("login"); // Obtiene el formulario de inicio de sesión por su ID
const apiUrlUser = "http://localhost:3000/users"; // URL de la API donde se realizarán las solicitudes

// Añade un evento al botón de registro para redirigir al usuario a la página de registro
document.getElementById('registerBtn').addEventListener('click', function() {
    window.location.href = 'Register.html'; // Redirige a la página de registro
});

// Añade un evento al formulario de inicio de sesión para manejar el envío
login.addEventListener('submit', (e) => {
    e.preventDefault(); // Previene el comportamiento predeterminado del formulario (recarga de página)
    const email = document.getElementById('email').value; // Obtiene el valor del campo de email
    const password = document.getElementById('password').value; // Obtiene el valor del campo de contraseña

    const loginUser = { email, password }; // Crea un objeto con el email y la contraseña

    // Verificar si el usuario inicia sesión
    fetch(`${apiUrlUser}?email=${email}&password=${password}`) // Realiza una solicitud GET a la API
    .then(response => response.json()) // Convierte la respuesta a formato JSON
    .then(users => {
        if (users.length > 0) { // Si hay usuarios en la respuesta
            window.location.href = 'dashboard.html'; // Redirige a la página del panel de control
            sessionStorage.setItem("Usuario logeado", JSON.stringify(users[0])); // Almacena el usuario en sessionStorage
        } else {
            // Si no existe el usuario, muestra un mensaje de alerta
            alert('Este usuario no existe'); // Informa al usuario que no se encontró
        }
    });
});


localStorage.setItem("Llave1","correo");
sessionStorage.setItem("Llave2", 123);
console.log(localStorage.getItem("Llave1"))
console.log(sessionStorage.getItem("Llave2"))
sessionStorage.removeItem("Llave2")
