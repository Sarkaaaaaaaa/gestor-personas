const apiUrlUser = "http://localhost:3000/users"; // URL de la API para gestionar usuarios
const formulario = document.getElementById("formulario"); // Selecciona el formulario por su ID

// Añade un evento al formulario para manejar el envío
formulario.addEventListener('submit', (e) => {
    e.preventDefault(); // Previene la recarga de página al enviar el formulario

    // Obtiene los valores de los campos del formulario
    const email = document.getElementById('email').value;
    const cedula = document.getElementById('cedula').value;
    const nombre = document.getElementById('nombre').value;
    const apellido = document.getElementById('apellido').value;
    const password = document.getElementById('password').value;

    // Crea un nuevo objeto de usuario con los datos recopilados
    const newUser = { nombre, apellido, email, password, cedula };

    // Verificar si el usuario ya existe
    fetch(`${apiUrlUser}?email=${email}`) // Realiza una solicitud GET a la API para verificar el email
    .then(response => response.json()) // Convierte la respuesta a formato JSON
    .then(users => {
        if (users.length > 0) { // Si ya existe un usuario con ese email
            alert('Este correo ya está registrado.'); // Muestra un mensaje de error
        } else {
            // Crear un nuevo usuario si no existe
            fetch(apiUrlUser, {
                method: 'POST', // Define el método HTTP como POST
                headers: {
                    'Content-Type': 'application/json' // Especifica el tipo de contenido
                },
                body: JSON.stringify(newUser) // Convierte el nuevo usuario a JSON
            })
            .then(response => response.json()) // Convierte la respuesta de la creación del usuario a JSON
            .then(user => {
                alert('Usuario registrado con éxito.'); // Notifica al usuario que el registro fue exitoso
                window.location.href = 'Inicio_sesion.html'; // Redirige a la página de inicio de sesión
                formulario.reset(); // Resetea el formulario
            });
        }
    });
});



